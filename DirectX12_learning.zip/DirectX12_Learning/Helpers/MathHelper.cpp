#include "../stdafx.h"
#include "MathHelper.h"

const float MathHelper::Pi = 3.1415926535f;
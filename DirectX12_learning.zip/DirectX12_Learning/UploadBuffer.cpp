#include "stdafx.h"
#include "UploadBuffer.h"
